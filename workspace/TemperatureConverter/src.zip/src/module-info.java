/**
 * 
 */
/**
 * @author H1710013
 *
 */
module Button {
	requires javafx.fxml;
	requires javafx.controls;
	exports application;
	opens application;
}