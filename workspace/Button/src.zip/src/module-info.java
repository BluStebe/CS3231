/**
 * 
 */
/**
 * @author H1710013
 *
 */
module Button {
	requires javafx.controls;
	exports application;
}